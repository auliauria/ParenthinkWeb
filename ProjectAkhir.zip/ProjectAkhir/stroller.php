<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stroller</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h2>Daftar Produk Stroller</h2>
    <table>
        <tr>
            <th>nama produk</th>
            <th>stok</th>
            <th>harga</th>
            <th>kategori</th>
        </tr>
        <?php
            // Include file koneksi
            include 'connectparenthink.php';
            
            // Query untuk mengambil data dari tabel event
            $query = "SELECT p.nama_produk, p.stok_produk, p.harga, k.nama_kategori 
            FROM produk p 
            JOIN kategori k ON p.id_kategoriproduk = k.id_kategoriproduk 
            WHERE p.id_kategoriproduk = 3;";
            $result = mysqli_query($conn, $query);
            
            // Looping untuk menampilkan data
            while ($row = mysqli_fetch_assoc($result)) {
                echo "
                <tr>
                    <td>".$row['nama_produk']."</td>
                    <td>".$row['stok_produk']."</td>
                    <td>".$row['harga']."</td>
                    <td>".$row['nama_kategori']."</td>
                </tr>
                ";
            }
            
            // Close koneksi
            mysqli_close($conn);
        ?>
    </table>
</body>
</html>
