<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "parenthink";

    //create connection
    $conn = mysqli_connect($servername, $username, $password, $database);

    //check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    // echo "Connected successfully";

    // $sql = "SELECT id_user, nama, username, email, password FROM user";
    // $result = mysqli_query($conn, $sql);

    // if (mysqli_num_rows($result) > 0) {
    //     while($row = mysqli_fetch_assoc($result)) {
    //         echo "id: " . $row["id_user"]. " " . "nama: " . $row["nama"]. " " . "username: " . $row["username"]. " " . "email: " . $row["email"]. " " . "password: " . $row["password"]. "<br>";
    //     }
    // }else{
    //     echo "0 results";
    // }

    // mysqli_close($conn);
?>