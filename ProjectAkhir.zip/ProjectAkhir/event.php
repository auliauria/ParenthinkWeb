<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List Event</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h2>Event terdekat</h2>
    <table>
        <tr>
            <th>id_event</th>
            <th>nama event</th>
            <th>tanggal event</th>
            <th>lokasi</th>
            <th>biaya registrasi</th>
        </tr>
        <?php
            // Include file koneksi
            include 'connectparenthink.php';
            
            // Query untuk mengambil data dari tabel event
            $query = "SELECT * FROM event";
            $result = mysqli_query($conn, $query);
            
            // Looping untuk menampilkan data
            while ($row = mysqli_fetch_assoc($result)) {
                echo "
                <tr>
                    <td>".$row['id_event']."</td>
                    <td>".$row['nama_event']."</td>
                    <td>".$row['event_date']."</td>
                    <td>".$row['alamat_event']."</td>
                    <td>".$row['biaya_registrasi']."</td>
                </tr>
                ";
            }
            
            // Close koneksi
            mysqli_close($conn);
        ?>
    </table>
</body>
</html>
