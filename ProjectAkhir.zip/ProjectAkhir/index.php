<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ParentThink</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <!-- font google -->
    <link href="https://fonts.googleapis.com/css2?family=Fuzzy+Bubbles:wght@400;700&family=Inter:wght@100..900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script defer src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

    <!-- Include Owl Carousel CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">

    <!-- Bootstrap CSS -->
    <!-- <link href="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/css/bootstrap.min.css" rel="stylesheet"> -->
    
</head>
<body>
    <svg xmlns="http://www.w3.org/2000/svg" style="display: none;">
        <symbol xmlns="http://www.w3.org/2000/svg" id="user" viewBox="0 0 16 16">
          <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3Zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z" />
        </symbol>
    </svg>
<script>
  alert("Selamat datang di website Parenthink Ayah Bunda!")
</script>
<header>
    <img src="images/logoparenthink.png" alt="ParentThink Logo" class="logo">
    <div class="navbar-container">
    <nav class="navbar navbar-expand-lg">
        <div class="container">
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="#">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">About</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">Parenthings</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">Class</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">Event</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">Contact</a>
              </li>
              <li class="nav-item">
                <div class="user-items ps-5">
                  <ul class="d-flex justify-content-end list-unstyled">
                    <li class="pe-3">
                      <a href="login.html">
                        <svg class="user">
                          <use xlink:href="#user"></use> <!--berisi ikon user/pengguna-->
                        </svg>
                      </a>
                    </li>
                  </ul>
                </div>
              </li>
            </ul>
          </div>
        </div>
    </nav>
    </div>
    <div class="family">
      <div class="caption">
          <h1>Welcome To Our Website</h1>
          <p>Bringing Beautiful Life To <br>Your Kids</p><br>
          <button>Learn More</button>
      </div>   
    </div>
</header>

<section class="about_section layout_padding">
  <div class="container-fluid">
    <div class="box">
      <div class="img-box">
        <img src="images/img1.png" alt="" />
      </div>
      <div class="detail-box">
        <h2>About Us</h2>
        <p>
        Selamat datang di Parenthink, sumber terpercaya Anda untuk semua informasi seputar pengasuhan anak. 
        Kami berdedikasi untuk membantu orang tua dalam menghadapi tantangan sehari-hari, memberikan tips praktis, 
        serta berbagi pengetahuan dari para ahli. Misi kami adalah menciptakan komunitas yang mendukung dan memberdayakan orang tua untuk memberikan yang terbaik bagi anak-anak mereka. 
        Bergabunglah dengan kami dalam perjalanan ini untuk membesarkan generasi yang bahagia dan sehat.
        </p>
        <a href="">
          <span>
            Read More
          </span>
          <hr />
        </a>
      </div>
    </div>
  </div>
</section>

<section class="service_section ">
  <div class="container">
    <div class="container-fluid">
      <div class="heading_container">
        <h2>
          Parenthings
        </h2>
      </div>
    </div>  
    <div class="row">
      <div class="col-lg-3 col-md-6">
        <div class="box">
          <div class="img-box">
            <img src="images/service1.png" alt="" />
          </div>
          <div class="detail-box">
            <h4>
              Baby Milk
            </h4>
            <p>
              Susu bayi berkualitas tinggi untuk memenuhi kebutuhan nutrisi si kecil, mendukung tumbuh kembang optimal.
            </p>
            <button><a href="babymilk.php" target="_blank">LIHAT</a></button>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-6">
        <div class="box ">
          <div class="img-box">
            <img src="images/service2.png" alt="" />
          </div>
          <div class="detail-box">
            <h4>
              Baby Clothes
            </h4>
            <p>
              Pakaian bayi yang nyaman dan stylish, terbuat dari bahan lembut dan aman untuk kulit sensitif bayi.
            </p>
            <button><a href="babyclothes.php">LIHAT</a></button>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-6">
        <div class="box">
          <div class="img-box">
            <img src="images/service3.png" alt="" />
          </div>
          <div class="detail-box">
            <h4>
              Stroller
            </h4>
            <p>
              Kereta dorong bayi yang ergonomis dan praktis, memastikan kenyamanan dan keamanan saat bepergian.
            </p>
            <button><a href="stroller.php">LIHAT</a></button>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-6">
        <div class="box">
          <div class="img-box">
            <img src="images/service4.png" alt="" />
          </div>
          <div class="detail-box">
            <h4>
              Baby Walk
            </h4>
            <p>
              Alat bantu jalan bayi yang dirancang untuk membantu bayi belajar berjalan dengan lebih mudah dan aman.
            </p>
            <button><a href="babywalk.php">LIHAT</a></button>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="class_section">
  <div>
    <h2>Class</h2>
  </div>
  <div class="carousel-container">
    <div id="carouselExampleInterval" class="carousel slide" data-bs-ride="carousel">
      <div class="carousel-inner">
        
          <div class="carousel-item active" data-bs-interval="10000">
            <img src="images/img2.png" class="d-block w-100" alt="...">
            <div class="detail-box1">
              <h3>Komunikasi Efektif :</h3>
              <p>Cara berkomunikasi yang baik antara orang tua dan anak.</p>
              <button>Learn More</button>
          </div>
          </div>
                
          <div class="carousel-item" data-bs-interval="2000">
            <img src="images/img3.png" class="d-block w-100" alt="...">
            <div class="detail-box1">
              <h3>Strategi Efektif :</h3>
              <p>Mengatasi Tantrum pada Anak Balita</p>
              <button>Learn More</button>
            </div>
          </div>
        
          <div class="carousel-item" data-bs-interval="2000">
            <img src="images/img4.png" class="d-block w-100" alt="...">
            <div class="detail-box1">
              <p>Membangun Komunikasi yang Baik dengan Remaja Anda</p>
              <button>Learn More</button>
            </div>
          </div>

          <div class="carousel-item" data-bs-interval="2000">
            <img src="images/img5.png" class="d-block w-100" alt="...">
            <div class="detail-box1">
              <p>Mengenali dan Mengembangkan Bakat Anak Sejak Dini</p>
              <button>Learn More</button>
            </div>
          </div>
        
      </div>
      <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleInterval" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleInterval" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
      </button>
    </div>
  </div>  
</section>

<section>
  <div class="event">
    <div class="header">Event</div>
    <div class="content">
        <img src="images/lombafoto.webp" alt="Event Photo">
        <div class="event-details">
            <h2>Lomba Foto Anak</h2>
            <p>Lomba Foto Anak adalah kesempatan sempurna untuk mengabadikan momen indah dan kreatif anak-anak Anda. 
               Acara ini terbuka untuk anak-anak dari berbagai usia, dengan berbagai kategori menarik untuk diikuti. 
               Selain dapat mengekspresikan bakat dan kreativitas mereka, peserta juga berkesempatan untuk memenangkan hadiah menarik. 
               Jangan lewatkan kesempatan ini untuk berbagi kebahagiaan dan keceriaan melalui fotografi!</p>
            <a href="registration.html" class="register-button">Daftar Event</a>
        </div>
    </div>
    <div class="other-events-link">
        <a href="event.php">IKUTI EVENT LAIN DI KOTAMU >>>></a>
    </div>
  </div>
</section>

<footer>
  <div class="footer">
    <div class="column about-us">
        <h5>About Us</h5>
        <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
    </div>
    <div class="column navigation">
        <h5>Navigation</h5>
        <ul>
            <li><a href="#">About Us</a></li>
            <li><a href="#">Terms and Service</a></li>
            <li><a href="#">Privacy</a></li>
            <li><a href="#">Contact Us</a></li>
        </ul>
    </div>
    <div class="column newsletter">
        <h5>Newsletter</h5>
        <form>
            <input type="email" placeholder="Email">
            <input type="submit" value="SEND">
        </form>
    </div>
    <div class="copyright">
      <p>Copyright © 2024 All rights reserved | This website is made with by Aulia</p>
    </div>
  </div>
</footer>


<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/js/bootstrap.min.js"></script>

</body>
</html>
